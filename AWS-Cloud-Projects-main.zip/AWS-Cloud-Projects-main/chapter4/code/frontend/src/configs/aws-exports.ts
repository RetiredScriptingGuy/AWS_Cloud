export const amplifyConfig = {
  aws_project_region: '[CognitoRegion]',
  aws_cognito_region: '[CognitoRegion]',
  aws_user_pools_id: '[UserPoolId]',
  aws_user_pools_web_client_id: '[UserPoolClientId]',
  };

