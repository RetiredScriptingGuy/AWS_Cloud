export const API_URL = "ApiUrl_OUTPUT";
