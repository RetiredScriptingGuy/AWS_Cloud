import RecipeContent from "../../components/RecipeContent/RecipeContent";

function UsersPage() {
  return (
    <div>
      <RecipeContent isAdmin={false} />
    </div>
  );
}

export default UsersPage;
