export const menuDetails = [
  {
    id: 0,
    icon: "",
    label: "Users",
    route: "users",
  },
  {
    id: 1,
    icon: "",
    label: "Admin",
    route: "admin",
  },
];
