export const CONFIG_MAX_INGREDIENTS = 20;
export const CONFIG_MAX_STEPS = 10;
export const CONFIG_MAX_RECIPES = 4;
export const CONFIG_ADMIN_PAGE_TITLE = "Admin";
export const CONFIG_USER_PAGE_TITLE = "User Page";
export const appConfig = {
  title: "My Recipe Sharing App",
  iconFileName: "ch3_link.png",
};
export const API_URL = "http://ec2-3-88-39-231.compute-1.amazonaws.com";
